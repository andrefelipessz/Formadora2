import { Component } from '@angular/core';
import { CepService } from '../services/cep.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-consulta-cep',
  templateUrl: './consulta-cep.page.html',
  styleUrls: ['./consulta-cep.page.scss'],
})
export class ConsultaCepPage {
  cep: string = '';
  erro: string = '';

  constructor(private cepService: CepService, private router: Router) {}

  buscarCep() {
    this.erro = '';
    
    if (this.cep.trim() === '') {
      this.erro = 'Por favor, digite um CEP válido.';
      return;
    }

    this.cepService.consultarCep(this.cep).subscribe(
      (dados) => {
        if (dados.erro) {
          this.erro = 'CEP não encontrado.';
        } else {
          this.router.navigate(['/mostrar-cep'], { state: { cep: dados } });
        }
      },
      (err) => {
        this.erro = 'Erro ao buscar o CEP. Verifique se ele está correto.';
      }
    );
  }
}
