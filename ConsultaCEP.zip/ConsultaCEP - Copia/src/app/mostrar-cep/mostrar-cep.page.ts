import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-mostrar-cep',
  templateUrl: './mostrar-cep.page.html',
  styleUrls: ['./mostrar-cep.page.scss'],
})
export class MostrarCepPage {
  cep: any = null;

  constructor(private router: Router) {
    const nav = this.router.getCurrentNavigation();
    if (nav?.extras?.state) {
      this.cep = nav.extras.state['cep'];
    }
  }
}
