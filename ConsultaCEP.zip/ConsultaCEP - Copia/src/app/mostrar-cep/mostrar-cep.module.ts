import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MostrarCepPageRoutingModule } from './mostrar-cep-routing.module';

import { MostrarCepPage } from './mostrar-cep.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MostrarCepPageRoutingModule
  ],
  declarations: [MostrarCepPage]
})
export class MostrarCepPageModule {}
