import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MostrarCepPage } from './mostrar-cep.page';

describe('MostrarCepPage', () => {
  let component: MostrarCepPage;
  let fixture: ComponentFixture<MostrarCepPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(MostrarCepPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
