import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MostrarCepPage } from './mostrar-cep.page';

const routes: Routes = [
  {
    path: '',
    component: MostrarCepPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MostrarCepPageRoutingModule {}
