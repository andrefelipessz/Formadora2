import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', loadChildren: () => import('./home/home.module').then( m => m.HomePageModule) },
  { path: 'consulta-cep', loadChildren: () => import('./consulta-cep/consulta-cep.module').then( m => m.ConsultaCepPageModule) },
  { path: 'mostrar-cep', loadChildren: () => import('./mostrar-cep/mostrar-cep.module').then( m => m.MostrarCepPageModule) },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
